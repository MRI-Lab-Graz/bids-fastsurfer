library(testthat)
library(bettermc)

test_check("bettermc")
